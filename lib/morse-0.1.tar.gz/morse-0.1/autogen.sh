#!/bin/sh

autoreconf -vfi

./configure $@
